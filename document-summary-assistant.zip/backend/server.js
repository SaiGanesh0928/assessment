import express from "express";
import cors from "cors";
import bodyParser from "body-parser";
import dotenv from "dotenv";
import { extractText } from "./utils/extractText.js";
import { generateSummary } from "./utils/summarize.js";

dotenv.config();

const app = express();
app.use(cors());
app.use(bodyParser.json({ limit: "50mb" }));

app.post("/upload", async (req, res) => {
  try {
    const { fileData, fileType } = req.body;
    const extracted = await extractText(fileData, fileType);
    res.json({ text: extracted });
  } catch {
    res.status(500).json({ error: "Text extraction failed" });
  }
});

app.post("/summarize", async (req, res) => {
  try {
    const { text, length } = req.body;
    const summary = await generateSummary(text, length);
    res.json({ summary });
  } catch {
    res.status(500).json({ error: "Summary failed" });
  }
});

app.listen(process.env.PORT, () =>
  console.log("Backend running on port", process.env.PORT)
);